package com.example.myapplication
import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.myapplication.Answer.ReplyScreen
import com.example.myapplication.MainMenu.MainMenu
import com.example.myapplication.MainMenu.MainMenuViewModel
import com.example.myapplication.Settings.SettingsMenu
import com.example.myapplication.Settings.SettingsViewModel
import android.content.Context
import java.io.File


val settingsViewModel = SettingsViewModel()

val mainViewModel = MainMenuViewModel()

@Composable
fun MyApp() {
    println("the selected langauge is" + settingsViewModel.selectedLanguage)
    val navController = rememberNavController()
    NavHostSetup(navController = navController)
}

@Composable
fun NavHostSetup(navController: NavHostController) {
    NavHost(
        navController = navController,
        startDestination = "home"
    ) {
        // Define the home screen route
        composable("home") {
            MainMenu(navController, mainViewModel,settingsViewModel)
        }

        // Define the second screen route

        composable("settings_menu") {
            SettingsMenu(navController, settingsViewModel)
        }

        composable("Reply_Screen") {
            ReplyScreen(navController, "The weather is nice, perfect for a walk.\n\n\n" +
                    "- Example 1: \"适合\" in \"适合穿这件衣服\" means \"suitable for wearing this outfit.\"\n" +
                    "- Example 2: \"适合\" can also indicate appropriateness, as in \"适合在这里工作\" (\"suitable for working here\")\n\n\n" +
                    "- 天气很好 (\"The weather is nice\"):\n" +
                    "- Structure: Subject-Verb (S-V) pattern.\n" +
                    "- Confidence Level: 95%.\n\n" +
                    "- 适合出去散步 (\"perfect for a walk\"):\n" +
                    "- Describes suitability for an activity.\n" +
                    "- Confidence Level: 90%.\n\n\n" +
                    "Overall Translation Confidence: High.\n" +
                    "Sentence Structure Confidence: 92%.\n" +
                    "Word Choice Confidence: 88%.")
        }
    }
}

fun readLinesFromFile(context: Context) {
    val file = File(context.filesDir, "ree.txt")
    val lines = file.readLines() // returns a list of strings, one per line

    for (line in lines) {
        println(line) // process each line as needed
    }
}