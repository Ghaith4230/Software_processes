package com.example.myapplication.MainMenu

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

class MainMenuViewModel {
    var text by mutableStateOf("")


    fun updateLanguage(newText: String) {
       text = newText
    }
}